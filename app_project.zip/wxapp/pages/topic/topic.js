Page({
    data: {
      topic: '',
      messages: [],
      inputText: ''
    }, 
    onLoad(arg) {
      this.setData({ topic: arg.topic });
    },
    onInput(event) {
      this.setData({ inputText: event.detail.value });
    },
    sendMessage() {
      const { inputText, messages } = this.data;
      if (inputText.trim()) {
        messages.push({ id: Date.now(), user: '我', text: inputText, type:'say' });
        messages.push({ id: Date.now(), user: 'AI', text: inputText, type:'echo' });
        this.setData({ messages, inputText: '' });
      }

      //TODO 把获取的字符串送到后台，请AI生成语音，并在界面里播放
    }
  });
  