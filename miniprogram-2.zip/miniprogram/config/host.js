const pro = 'https://www.myapp.com';
const dev = 'http://192.168.5.155:8080';
const path = '/aihola';
const domain = dev.concat(path);

export default domain;