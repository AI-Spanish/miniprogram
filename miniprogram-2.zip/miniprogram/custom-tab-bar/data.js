export default [
  {
    icon: "home",
    text: "首页",
    url: "pages/login/login",
  },
  {
    icon: "comment",
    text: "聊天",
    url: "pages/index/index",
  },
  {
    icon: "sort",
    text: "情景",
    url: "pages/records/records",
  },
  {
    icon: "person",
    text: "个人中心",
    url: "pages/settings/settings",
  },
];
