import {login} from '../../api/user'

//微信登录： https://zhuanlan.zhihu.com/p/620589067

Page({
    openId: "",
    data: {
        //判断小程序的API，回调，参数，组件等是否在当前版本可用。
        canIUse: wx.canIUse('button.open-type.getUserInfo'), 
        canIUseGetPhoneNumber: wx.canIUse('button.open-type.getPhoneNumber'), 
        canIUseGetUserProfile: wx.canIUse('button.open-type.getUserProfile'), 

        hide_login_btn: false
    },
    onClose() {
        this.setData({
        });
    },

    _goAheadToIndexPage(){
        wx.reLaunch({
            url: '/pages/index/index?from=login',
        })
    },
   
    _loginSuccess: function(data) {
        // 保存登录信息
        wx.setStorageSync('token', data.token);
        //wx.setStorageSync('openid', data.openid);

        // 显示提示
        wx.showToast({
            title: '登录成功',
            icon: 'none',
            duration: 2000,
            success: res => {
                this._goAheadToIndexPage()
            }
        })
    },

    _loginFail: function(reason, res) {
        console.log(reason,":",res)

        let msg = "服务器提示："
        switch(reason){
            case 1: {
                msg  += JSON.stringify(res)
                break;
            }
            default:{
                msg = `调用出现未知错误[${reason}]，请通知我们，非常感谢！`
            }
        }
        wx.showModal({
            title: '登录失败',
            content: msg,
            showCancel: false,
            confirmText: "确定",
        })
    },

    //用微信登录后台
    wxLogin() {
        login().then(res => {
            if(res?.token==undefined){
                this._loginFail(0,res)
            } else {
                this._loginSuccess(res);
            }
        }).catch(err => {
            this._loginFail(1,err) 
        })
    },

    wxLoginFake() {
        this._loginSuccess(
            {
                token:"12345678"
            }
        );
    }
})
