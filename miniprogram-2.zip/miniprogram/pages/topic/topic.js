Page({
    data: {
      topic: '',
      messages: [],
      inputText: '',

      autosize: {
        minRows: 1,
        maxRows: 5,
      }
    }, 
    onLoad(arg) {
      this.setData({ topic: arg.topic });
    },
    onShow(){
      if (typeof this.getTabBar === 'function') {
        console.log("切换到tabBar 1");
        this.getTabBar((tabBar) => {
          tabBar.setData({
            active:1
          })
        })
      }
    },

    onInput(event) {
      let str  = event.detail.value;
      this.setData({ inputText: str });
    },

    sendMessage() {
      const { inputText, messages } = this.data;
      if (inputText.trim()) {
        messages.push({ id: Date.now(), user: '我', text: inputText, type:'say' });
        //TODO 把inputText发到服务器，获取echo
        messages.push({ id: Date.now(), user: '西语AI', text: inputText, type:'echo' });
        this.setData({ messages, inputText: '' });
      }
    },

    onInputheightChange(e) {
      //console.log("keyboardheight===", e.detail.height);
      this.setData({
        keyboardheight: e.detail.height ? `${e.detail.height + 20}px` : undefined,
      });
    },
    onLineChange(e) {
      //console.log("lineCount: ", e.detail);
    }
  });
  